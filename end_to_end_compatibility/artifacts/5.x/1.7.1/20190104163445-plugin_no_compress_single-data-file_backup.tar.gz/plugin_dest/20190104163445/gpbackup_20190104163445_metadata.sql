
SET client_encoding = 'UTF8';


CREATE DATABASE testdb TEMPLATE template0 ENCODING 'UTF8';

ALTER DATABASE testdb OWNER TO pivotal;


ALTER RESOURCE QUEUE pg_default WITH (ACTIVE_STATEMENTS=20);

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 10;

ALTER RESOURCE GROUP admin_group SET MEMORY_SHARED_QUOTA 50;

ALTER RESOURCE GROUP admin_group SET MEMORY_SPILL_RATIO 20;

ALTER RESOURCE GROUP admin_group SET CONCURRENCY 10;

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 10;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 20;

ALTER RESOURCE GROUP default_group SET MEMORY_SHARED_QUOTA 25;

ALTER RESOURCE GROUP default_group SET MEMORY_SPILL_RATIO 30;

ALTER RESOURCE GROUP default_group SET CONCURRENCY 15;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 10;

CREATE ROLE pivotal;
ALTER ROLE pivotal WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN PASSWORD 'md5d946b5e7943aa784c967b1f388b7d330' RESOURCE QUEUE pg_default RESOURCE GROUP admin_group CREATEEXTTABLE (protocol='http') CREATEEXTTABLE (protocol='gpfdist', type='readable') CREATEEXTTABLE (protocol='gpfdist', type='writable') CREATEEXTTABLE (protocol='gphdfs', type='readable') CREATEEXTTABLE (protocol='gphdfs', type='writable');




COMMENT ON SCHEMA public IS 'standard public schema';


ALTER SCHEMA public OWNER TO pivotal;


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM pivotal;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO pivotal;


CREATE SCHEMA schema2;

ALTER SCHEMA schema2 OWNER TO pivotal;




CREATE SEQUENCE public.myseq1
	START WITH 100
	INCREMENT BY 1
	NO MAXVALUE
	NO MINVALUE
	CACHE 1;

SELECT pg_catalog.setval('public.myseq1', 100, false);


ALTER TABLE public.myseq1 OWNER TO pivotal;


CREATE SEQUENCE public.myseq2
	START WITH 100
	INCREMENT BY 1
	NO MAXVALUE
	NO MINVALUE
	CACHE 1;

SELECT pg_catalog.setval('public.myseq2', 100, false);


ALTER TABLE public.myseq2 OWNER TO pivotal;


CREATE TABLE public.foo (
	i integer DEFAULT nextval('public.myseq1'::regclass) NOT NULL
) DISTRIBUTED BY (i);


ALTER TABLE public.foo OWNER TO pivotal;


CREATE TABLE public.holds (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE public.holds OWNER TO pivotal;


CREATE TABLE public.sales (
	id integer,
	date date,
	amt numeric(10,2)
) DISTRIBUTED BY (id) PARTITION BY RANGE(date) 
          (
          PARTITION jan17 START ('2017-01-01'::date) END ('2017-02-01'::date) WITH (tablename='sales_1_prt_jan17', appendonly=false ), 
          PARTITION feb17 START ('2017-02-01'::date) END ('2017-03-01'::date) WITH (tablename='sales_1_prt_feb17', appendonly=false ), 
          PARTITION mar17 START ('2017-03-01'::date) END ('2017-04-01'::date) WITH (tablename='sales_1_prt_mar17', appendonly=false ), 
          PARTITION apr17 START ('2017-04-01'::date) END ('2017-05-01'::date) WITH (tablename='sales_1_prt_apr17', appendonly=false ), 
          PARTITION may17 START ('2017-05-01'::date) END ('2017-06-01'::date) WITH (tablename='sales_1_prt_may17', appendonly=false ), 
          PARTITION jun17 START ('2017-06-01'::date) END ('2017-07-01'::date) WITH (tablename='sales_1_prt_jun17', appendonly=false ), 
          PARTITION jul17 START ('2017-07-01'::date) END ('2017-08-01'::date) WITH (tablename='sales_1_prt_jul17', appendonly=false ), 
          PARTITION aug17 START ('2017-08-01'::date) END ('2017-09-01'::date) WITH (tablename='sales_1_prt_aug17', appendonly=false ), 
          PARTITION sep17 START ('2017-09-01'::date) END ('2017-10-01'::date) WITH (tablename='sales_1_prt_sep17', appendonly=false ), 
          PARTITION oct17 START ('2017-10-01'::date) END ('2017-11-01'::date) WITH (tablename='sales_1_prt_oct17', appendonly=false ), 
          PARTITION nov17 START ('2017-11-01'::date) END ('2017-12-01'::date) WITH (tablename='sales_1_prt_nov17', appendonly=false ), 
          PARTITION dec17 START ('2017-12-01'::date) END ('2018-01-01'::date) WITH (tablename='sales_1_prt_dec17', appendonly=false )
          );


ALTER TABLE public.sales OWNER TO pivotal;


CREATE TABLE schema2.foo2 (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schema2.foo2 OWNER TO pivotal;


CREATE TABLE schema2.foo3 (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schema2.foo3 OWNER TO pivotal;


CREATE TABLE schema2.returns (
	id integer,
	date date,
	amt numeric(10,2)
) DISTRIBUTED BY (id) PARTITION BY RANGE(date) 
          (
          PARTITION jan17 START ('2017-01-01'::date) END ('2017-02-01'::date) WITH (tablename='returns_1_prt_jan17', appendonly=false ), 
          PARTITION feb17 START ('2017-02-01'::date) END ('2017-03-01'::date) WITH (tablename='returns_1_prt_feb17', appendonly=false ), 
          PARTITION mar17 START ('2017-03-01'::date) END ('2017-04-01'::date) WITH (tablename='returns_1_prt_mar17', appendonly=false ), 
          PARTITION apr17 START ('2017-04-01'::date) END ('2017-05-01'::date) WITH (tablename='returns_1_prt_apr17', appendonly=false ), 
          PARTITION may17 START ('2017-05-01'::date) END ('2017-06-01'::date) WITH (tablename='returns_1_prt_may17', appendonly=false ), 
          PARTITION jun17 START ('2017-06-01'::date) END ('2017-07-01'::date) WITH (tablename='returns_1_prt_jun17', appendonly=false ), 
          PARTITION jul17 START ('2017-07-01'::date) END ('2017-08-01'::date) WITH (tablename='returns_1_prt_jul17', appendonly=false ), 
          PARTITION aug17 START ('2017-08-01'::date) END ('2017-09-01'::date) WITH (tablename='returns_1_prt_aug17', appendonly=false ), 
          PARTITION sep17 START ('2017-09-01'::date) END ('2017-10-01'::date) WITH (tablename='returns_1_prt_sep17', appendonly=false ), 
          PARTITION oct17 START ('2017-10-01'::date) END ('2017-11-01'::date) WITH (tablename='returns_1_prt_oct17', appendonly=false ), 
          PARTITION nov17 START ('2017-11-01'::date) END ('2017-12-01'::date) WITH (tablename='returns_1_prt_nov17', appendonly=false ), 
          PARTITION dec17 START ('2017-12-01'::date) END ('2018-01-01'::date) WITH (tablename='returns_1_prt_dec17', appendonly=false )
          );


ALTER TABLE schema2.returns OWNER TO pivotal;


CREATE TABLE schema2.ao1 (
	i integer
) WITH (appendonly=true) DISTRIBUTED BY (i);


ALTER TABLE schema2.ao1 OWNER TO pivotal;


CREATE TABLE schema2.ao2 (
	i integer ENCODING (compresstype=none,blocksize=32768,compresslevel=0)
) WITH (appendonly=true, orientation=column) DISTRIBUTED BY (i);


ALTER TABLE schema2.ao2 OWNER TO pivotal;


CREATE VIEW public.myview2 AS SELECT '1';


ALTER TABLE public.myview2 OWNER TO pivotal;


CREATE VIEW public.myview1 AS SELECT foo.i FROM public.foo;


ALTER TABLE public.myview1 OWNER TO pivotal;
